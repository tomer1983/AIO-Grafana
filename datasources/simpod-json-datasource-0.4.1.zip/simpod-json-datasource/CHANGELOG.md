# Changelog

## v0.2.4

- Fixed order of processing Additional JSON, so we're first replacing variables and JSON parse after that in #149 (@istvan86-nagy)

## v0.2.3

- Upgrade deps to @grafana v7.3
- Require Grafana 7.3
